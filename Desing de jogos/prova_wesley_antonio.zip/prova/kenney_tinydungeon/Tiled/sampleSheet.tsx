<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="tileset" tilewidth="16" tileheight="16" spacing="1" tilecount="132" columns="12">
 <image source="../Tilemap/tilemap.png" width="203" height="186"/>
</tileset>
