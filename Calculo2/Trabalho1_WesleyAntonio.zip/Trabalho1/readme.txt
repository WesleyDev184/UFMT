Precisa da biblioteca "matplotlib" Para a plotagem do gráfico se nao tiver instalada so rodar o comando:

pip install matplotlib
